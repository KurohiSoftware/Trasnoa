from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from django.conf import settings
import io
import dateutil.parser

def crear_pdf_estadistica(lista_numeros,lista_aceites):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer,pagesize=A4)
    w, h = A4
    archivo_imagen = str(settings.BASE_DIR)+'/plataforma/static/plataforma/logo.jpeg'
    p.drawImage(archivo_imagen, 45, 740, 120, 90,preserveAspectRatio=True)
    p.drawString(186, h-60, "MANTENIMIENTO - ZONA NORTE / Estadística de codigos numericos")
    p.line(55,h-80,w-30,h-80)
    p = estadistica(p,lista_numeros)
    w, h = A4
    archivo_imagen = str(settings.BASE_DIR)+'/plataforma/static/plataforma/logo.jpeg'
    p.drawImage(archivo_imagen, 45, 740, 120, 90,preserveAspectRatio=True)
    p.drawString(176, h-60, "MANTENIMIENTO - ZONA NORTE / Estadística de codigos SF6 y aceite")
    p.line(55,h-80,w-30,h-80)
    p = estadistica(p,lista_aceites)
    p.save()
    buffer.seek(0)
    return buffer

def estadistica(p,lista):
    p.setTitle("Planilla")
    w, h = A4
    x = 100
    y = ""
    for i in range(0,len(lista)):
        if type(lista[i]) == str:
            p.setFillColor("red")
            p.drawString(55, h-x, "EETT: "+lista[i])
            p.setFillColor("black")
            x += 20
        else:
            placeholder = []
            relleno = []
            for j in range(0,len(lista[i])):
                z = lista[i][0]
                if y != z:
                    y = z
                    placeholder.append(["Codigo: "+y])
                    t=Table(placeholder,repeatRows=1,colWidths=[509],style=[('BOX', (0,0), (-1,-1), 0.25, colors.black),('BACKGROUND',(0,0), (-1,-1),colors.ReportLabBlue),('TEXTCOLOR',(0,0), (-1,-1),colors.white),])
                    t.wrapOn(p, w, h)
                    x += 12
                    t.drawOn(p, 56, h-x)
                    x += 18
                    placeholder = []
                    placeholder.append(["Fecha","Valor","Instalación - Equipamiento"])
                    t=Table(placeholder,repeatRows=1,colWidths=[103, 103, 303],style=[('BOX', (0,0), (-1,-1), 0.25, colors.black),('INNERGRID', (0,0), (-1,-1), 0.25, colors.black)])
                    t.wrapOn(p, w, h)
                    t.drawOn(p, 56, h-x)
                    x += 19
                    placeholder = []
                else:
                    if y != lista[i][j]:
                        relleno.append(lista[i][j])
            placeholder.append(relleno)
            t=Table(placeholder,repeatRows=1,colWidths=[103, 103, 303],style=[('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),('LINEBELOW', (0,-1), (-1,-1), 1, colors.black)])
            t.wrapOn(p, w, h)
            t.drawOn(p, 56, h-x)
            if x < 750:
                x = x + 19
            else:
                page_num = str(p.getPageNumber())
                p.drawString(w-35, h-832, page_num)
                p.line(55,h-815,w-30,h-815)
                p.showPage()
                x = 40
    page_num = str(p.getPageNumber())
    p.drawString(w-35, h-832, page_num)
    p.line(55,h-815,w-30,h-815)
    p.showPage()
    return p

def crear_pdf(plantilla):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer,pagesize=A4)
    p = base_pdf(p,plantilla)
    p.save()
    buffer.seek(0)
    return buffer


def crear_lista_pdf(plantillas):
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer,pagesize=A4)
    for plantilla in plantillas:
        p = base_pdf(p,plantilla)
    p.save()
    buffer.seek(0)
    return buffer

def base_pdf(p,plantilla):
    p.setTitle("Planilla")
    w, h = A4
    archivo_imagen = str(settings.BASE_DIR)+'/plataforma/static/plataforma/logo.jpeg'
    p.drawImage(archivo_imagen, 45, 740, 120, 90,preserveAspectRatio=True)
    p.drawString(375, h-60, "MANTENIMIENTO - ZONA NORTE")
    p.line(55,h-80,w-30,h-80)
    fecha = str(plantilla.fecha)
    fecha = dateutil.parser.parse(fecha)
    fecha = fecha.strftime('%d/%m/%Y %H:%M') 
    fecha_subida = str(plantilla.fecha_subida)
    fecha_subida = dateutil.parser.parse(fecha_subida)
    fecha_subida = fecha_subida.strftime('%d/%m/%Y %H:%M') 
    p.drawString(55, h-100, "Estacion Transformadora: "+plantilla.eett.username)
    p.drawString(55, h-120, "Operador: "+plantilla.operador)
    p.drawString(55, h-140, "DNI: "+plantilla.DNI)
    p.drawString(55, h-160, "Tipo de chequeo: "+plantilla.tipo)
    p.drawString(355, h-100, "Fecha de realización: "+fecha)
    p.drawString(355, h-120, "Fecha de subida: "+fecha_subida)
    p.drawString(355, h-140, "Temperatura: "+plantilla.temperatura)
    p.drawString(355, h-160, "Clima: "+plantilla.clima)
    data = [["Codigo","Tipo","Observación","Instalación - Equipamiento"]]
    t=Table(data,repeatRows=1,colWidths=[85, 85, 200, 155])
    width = 200
    height = 200
    t.wrapOn(p, w, h)
    t.drawOn(p, 50, h-190)
    x = 190
    for contenido in plantilla.contenido.all():
        if x < 800:
            x = x + 15
        else:
            page_num = str(p.getPageNumber())
            p.drawString(w-35, h-832, page_num)
            p.line(55,h-815,w-30,h-815)
            p.showPage()
            x = 40
        placeholder = []
        data=[]
        placeholder.append(Paragraph(contenido.codigo))
        placeholder.append(contenido.clase)
        cantidad_caracteres_observacion = len(contenido.observacion)
        cantidad_caracteres_observacion = int(cantidad_caracteres_observacion/48)
        cantidad_caracteres_identificador = len(contenido.identificador.lower())
        cantidad_caracteres_identificador = int(cantidad_caracteres_identificador/25)
        if cantidad_caracteres_observacion > cantidad_caracteres_identificador:
            x = x + cantidad_caracteres_observacion*15
        else:
            x = x + cantidad_caracteres_identificador*10
        descrpcion = Paragraph(contenido.observacion)
        placeholder.append(descrpcion)
        identificador = Paragraph(contenido.identificador)
        placeholder.append(identificador)
        data.append(placeholder)
        t=Table(data,repeatRows=1,colWidths=[85, 85, 200, 155],splitInRow=20)
        t.wrapOn(p, width, height)
        t.drawOn(p, 50, h-x)
    page_num = str(p.getPageNumber())
    p.drawString(w-35, h-832, page_num)
    p.line(55,h-815,w-30,h-815)
    p.showPage()
    return p 
