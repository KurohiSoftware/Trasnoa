from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect , JsonResponse
from django.shortcuts import render, redirect, reverse
from .models import User,Plantilla,Contenido,Mensaje
from django.contrib.auth.decorators import login_required

from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from datetime import datetime
from django.http import FileResponse, Http404
from django.contrib.auth.decorators import permission_required
from django.core.paginator import Paginator

from pathlib import Path
import os
from . import util


def index(request):
    return render(request, "plataforma/inicio.html")

def crear_cuentas(request):
    return render(request, "plataforma/crear_cuentas.html")

def ingresar(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        # Check if authentication successful
        if user is not None:
            login(request, user)
            if request.user.is_superuser or user.rol == 3:
                return HttpResponseRedirect(reverse("crear_cuentas"))
            if user.rol == 1:
                return HttpResponseRedirect(reverse("inicio_admin"))
            if user.rol == 2:
                return HttpResponseRedirect(reverse("inicio_estacion"))
        else:
            return render(request, "plataforma/index.html", {
                "message": "Usuario o contraseña incorrecta"
            })
    else:
        return HttpResponseRedirect(reverse("index"))
    
def registrar(request):
    content_type = ContentType.objects.get_for_model(User)
    post_permission = Permission.objects.filter(content_type=content_type)
    for post in post_permission:
        string = str(post)
        if 'is_admin' in string:
            admin = post
        if 'is_eett' in string:
            eett = post
        if 'is_creador' in string:
            creador = post
    if request.method == "POST":
        #Agarra informacion y valida
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        sede = request.POST["sede"]
        rol = request.POST["rol"]
        if password != confirmation:
            return render(request, "plataforma/crear_cuentas.html", {
                "message": "Passwords must match."
            })
        # Permissions
        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.sede = sede
            if rol == "admin":
                user.rol = 1
                user.user_permissions.add(admin)
            if rol == "estacion":
                user.rol = 2
                user.user_permissions.add(eett)
            if rol == "creador":
                user.rol = 3
                user.user_permissions.add(creador)
            user.save()
        except IntegrityError:
            return render(request, "plataforma/crear_cuentas.html", {
                "message": "Username already taken."
            })
        return HttpResponseRedirect(reverse("crear_cuentas"))
    else:
        return render(request, "plataforma/crear_cuentas.html")
    
def cerrar_sesion(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))

@login_required
def inicio_estacion(request):
    cantidad_contenido = list(range(1,21))
    if request.method == "POST":
        ad = 0
        try:
            eett = request.POST['eett']
            user = User.objects.get(username=eett)
            eett = user
            ad = 1
        except:
            eett=request.user
        operador = request.POST['operador'].strip()
        dni = request.POST['dni'].strip()
        temperatura_ambiente = request.POST['temperatura_ambiente'].strip()
        clima = request.POST['clima'].strip()
        FyH = request.POST['FyH']
        tipo_de_chequeo = request.POST['tipo_de_chequeo']
        FyHActual = datetime.now()
        nueva_plantilla = Plantilla(eett=eett,fecha=FyH,fecha_subida=FyHActual,operador=operador,DNI=dni,temperatura=temperatura_ambiente,clima=clima,tipo=tipo_de_chequeo)
        contador_django = request.POST['contador_django']
        aceites = ["EP03S09","EP06D0101","EP06D0103","EP07D0101","EP07D0103","CT08S04","CT08S05","CT10S02","CT11D0201","CT11D0202","CL20D0401","CL20D0402","CL22S01","CL23S01","CT13S01"]
        nueva_plantilla.save()
        lista_avisos = []
        for i in range(1,int(contador_django)+1):
            codigo = request.POST['codigo_'+str(i)].strip().upper()
            tipo_chequeo = request.POST['tipo_chequeo_'+str(i)]
            observacion = request.POST['observacion_'+str(i)]
            identificador = request.POST['identificador_'+str(i)]
            if codigo != '':
                contenido = Contenido.objects.create(codigo = codigo,clase = tipo_chequeo,observacion = observacion,identificador = identificador)
                nueva_plantilla.contenido.add(contenido)
                if codigo in aceites:
                    if observacion == "Minimo" or observacion == "Menor que minimo":
                        lista_avisos.append(contenido)
        if len(lista_avisos) != 0:
            admins = User.objects.filter(sede=request.user.sede,rol=1)
            for admin in admins:
                mensaje = Mensaje(receptor = admin,plantilla = nueva_plantilla)
                mensaje.save()
                for contenido in lista_avisos:
                    mensaje.avisos.add(contenido)
        if ad == 0:
            return render(request, "plataforma/estacion_inicio.html",{"cantidad_contenido":cantidad_contenido,"message":"Planilla subida con exito"})
        else:
            return HttpResponseRedirect(reverse("admin_ver_plantilla",args=[nueva_plantilla.id]))

    if request.method == "GET":
        return render(request, "plataforma/estacion_inicio.html",{"cantidad_contenido":cantidad_contenido})

@login_required
def ver_checklist(request):
    try:
        filepath = os.path.join('plataforma/static/plataforma', 'check_list_et.pdf')
        with open(filepath, "rb") as fprb:
            response = HttpResponse(fprb.read(), content_type="pdf")
            response["Content-Disposition"] = "attachment; filename=CheckList.pdf"
            return response
    except FileNotFoundError:
        raise Http404()

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def inicio_admin(request):
    avisos = Mensaje.objects.filter(receptor = request.user)
    avisos = avisos.order_by("-plantilla_id").all()
    paginator = Paginator(avisos, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, "plataforma/admin_inicio.html",{"page_obj":page_obj})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def ver_aviso(request,aviso_id):
    aviso = Mensaje.objects.get(id = aviso_id)
    return render(request, "plataforma/aviso.html",{"aviso":aviso})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def leido(request,aviso_id):
    aviso = Mensaje.objects.get(id = aviso_id)
    aviso.leido = True
    aviso.save()
    return HttpResponseRedirect(reverse("ver_aviso",args=[aviso_id]))

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def no_leido(request,aviso_id):
    aviso = Mensaje.objects.get(id = aviso_id)
    aviso.leido = False
    aviso.save()
    return HttpResponseRedirect(reverse("ver_aviso",args=[aviso_id]))

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def ver_estaciones(request):
    estaciones = User.objects.filter(sede=request.user.sede,rol=2)
    return render(request, "plataforma/ver_estaciones.html",{"estaciones":estaciones})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_plantillas(request):
    estaciones = User.objects.filter(rol=2,sede=request.user.sede)
    plantillas = Plantilla.objects.filter(eett__in=estaciones)
    return render(request, "plataforma/admin_plantillas.html",{"plantillas":plantillas})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_ver_plantilla(request,plantilla_id):
    try:
        plantilla = Plantilla.objects.get(pk=plantilla_id)
    except:
        return render(request, "plataforma/error.html",{"tipo_error":"No se puede realizar esta accion ya que la plantilla ya no existe"})
    return render(request, "plataforma/admin_ver_plantilla.html",{"plantilla":plantilla})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_descargar_planilla(request,plantilla_id):
    try:
        plantilla = Plantilla.objects.get(pk=plantilla_id)
    except:
        return render(request, "plataforma/error.html",{"tipo_error":"No se puede realizar esta accion ya que la plantilla ya no existe"})
    buffer = util.crear_pdf(plantilla)
    response = HttpResponse(buffer, content_type="pdf")
    nombre = plantilla.eett.username+" ("+str(plantilla.fecha)+").pdf"
    response["Content-Disposition"] = f'attachment; filename={nombre}'
    return response
    #return FileResponse(buffer, content_type='application/pdf', filename=(plantilla.eett.username+" ("+str(plantilla.fecha)+")"))

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_modificar_plantilla(request,plantilla_id):
    try:
        plantilla = Plantilla.objects.get(pk=plantilla_id)
    except:
        return render(request, "plataforma/error.html",{"tipo_error":"No se puede realizar esta accion ya que la plantilla ya no existe"})
    estaciones = User.objects.filter(rol=2,sede=request.user.sede)
    if request.method == "POST":
        eett = request.POST['eett']
        user_place = User.objects.get(username=eett)
        eett = user_place
        operador = request.POST['operador']
        dni = request.POST['dni']
        temperatura_ambiente = request.POST['temperatura_ambiente']
        clima = request.POST['clima']
        try:
            FyH = request.POST['FyH']
        except:
            FyH = plantilla.fecha
        tipo_de_chequeo = request.POST['tipo_de_chequeo']
        plantilla.eett = eett
        plantilla.fecha = FyH
        plantilla.operador = operador
        plantilla.DNI = dni
        plantilla.temperatura = temperatura_ambiente
        plantilla.clima = clima
        plantilla.tipo = tipo_de_chequeo
        plantilla.save()
        aceites = ["EP03S09","EP06D0101","EP06D0103","EP07D0101","EP07D0103","CT08S04","CT08S05","CT10S02","CT11D0201","CT11D0202","CL20D0401","CL20D0402","CL22S01","CL23S01","CT13S01"]
        lista_avisos = []
        for contenido in plantilla.contenido.all():
            Contenido.objects.filter(id=contenido.id).delete()
        contador_django = request.POST['contador_django']
        for i in range(1,int(contador_django)+1):
            codigo = request.POST['codigo_'+str(i)].strip().upper()
            tipo_chequeo = request.POST['tipo_chequeo_'+str(i)]
            observacion = request.POST['observacion_'+str(i)]
            identificador = request.POST['identificador_'+str(i)]
            if codigo != '':
                contenido = Contenido.objects.create(codigo = codigo,clase = tipo_chequeo,observacion = observacion,identificador = identificador)
                plantilla.contenido.add(contenido)
                if codigo in aceites:
                    if observacion == "Minimo" or observacion == "Menor que minimo":
                        lista_avisos.append(contenido)
        Mensaje.objects.filter(plantilla=plantilla_id).delete()
        if len(lista_avisos) != 0:
            admins = User.objects.filter(sede=request.user.sede,rol=1)
            for admin in admins:
                mensaje = Mensaje(receptor = admin,plantilla = plantilla)
                mensaje.save()
                for contenido in lista_avisos:
                    mensaje.avisos.add(contenido)
        return HttpResponseRedirect(reverse("admin_ver_plantilla",args=[plantilla_id]))
    contador_viejo = len(plantilla.contenido.all())
    return render(request, "plataforma/admin_modificar_plantilla.html",{"plantilla":plantilla,"estaciones":estaciones,"contador_viejo":contador_viejo})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_agregar_plantilla(request):
    cantidad_contenido = list(range(1,21))
    estaciones = User.objects.filter(rol=2,sede=request.user.sede)
    return render(request, "plataforma/admin_agregar_plantilla.html",{"cantidad_contenido":cantidad_contenido,"estaciones":estaciones})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_eliminar(request,plantilla_eliminar):
    try:
        plantilla = Plantilla.objects.get(pk=plantilla_eliminar)
    except:
        return render(request, "plataforma/error.html",{"tipo_error":"No se puede realizar esta accion ya que la plantilla ya no existe"})
    for contenido in plantilla.contenido.all():
        Contenido.objects.filter(id=contenido.id).delete()
    Plantilla.objects.filter(id=plantilla_eliminar).delete()
    return HttpResponseRedirect(reverse("admin_plantillas"))

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def cambiar_contrasena(request,usuario_id):
    try:
        user = User.objects.get(pk=usuario_id)
    except:
        return render(request, "plataforma/error.html",{"tipo_error":"No se puede realizar esta accion ya que el usuario ya no existe"})
    if request.method == "POST":
        nueva = request.POST['password']
        user.set_password(nueva)
        user.save()
        return HttpResponseRedirect(reverse("inicio_admin"))
    return render(request, "plataforma/cambiar_contrasena.html",{"estacion":user})

def plantillas_json(request):
    estaciones = User.objects.filter(rol=2,sede=request.user.sede)
    plantillas = Plantilla.objects.filter(eett__in=estaciones)
    plantillas = plantillas.order_by("-fecha").all()
    return JsonResponse([plantilla.serialize() for plantilla in plantillas], safe=False)

def error(request,tipo_error):
    return render(request, "plataforma/error.html",{"tipo_error":tipo_error})

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_estadistica(request):
    estaciones = User.objects.filter(rol=2,sede=request.user.sede)
    plantillas = Plantilla.objects.filter(eett__in=estaciones)
    plantillas= plantillas.order_by("eett").all()
    numeros = ["EP03S01", "EP03S02","EP03S03","CT08S07","CT08S09","CT11D01","CL20D01","CL20D02","CL20D03","CT14D02","CT15D02","CT16D02","CL25D02"]
    aceites = ["EP03S09","EP06D0101","EP06D0103","EP07D0101","EP07D0103","CT08S04","CT08S05","CT10S02","CT11D0201","CT11D0202","CL20D0401","CL20D0402","CL22S01","CL23S01","CT13S01"]
    lista_numeros = []
    lista_aceites = []
    for plantilla in plantillas:
        if not plantilla.eett.username in lista_numeros:
            lista_numeros.append(plantilla.eett.username)
        if not plantilla.eett.username in lista_aceites:
            lista_aceites.append(plantilla.eett.username)
        for contenido in plantilla.contenido.all():
            if contenido.codigo in numeros:
                lista_numeros.append([contenido.codigo,plantilla.fecha.strftime("%d/%m/%Y, %H:%M"),contenido.observacion,contenido.identificador])
            if contenido.codigo in aceites:
                lista_aceites.append([contenido.codigo,plantilla.fecha.strftime("%d/%m/%Y, %H:%M"),contenido.observacion,contenido.identificador])
    estadistica = util.crear_pdf_estadistica(lista_numeros,lista_aceites)
    now = datetime.now()
    now = datetime.strftime(now,format="%d-%m-%Y %H:%M")
    response = HttpResponse(estadistica, content_type="pdf")
    nombre = "Estadistica_"+request.user.sede+" ("+str(now)+").pdf"
    response["Content-Disposition"] = f'attachment; filename={nombre}'
    return response
    #return FileResponse(estadistica, content_type='application/pdf', filename=("Estadistica_"+request.user.sede+" ("+str(now)+")"))

@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_todos_pdf(request):
    estaciones = User.objects.filter(rol=2,sede=request.user.sede)
    plantillas = Plantilla.objects.filter(eett__in=estaciones)
    plantillas= plantillas.order_by("eett").all()
    todos_pdf = util.crear_lista_pdf(plantillas)
    now = datetime.now()
    now = datetime.strftime(now,format="%d-%m-%Y %H:%M")
    response = HttpResponse(todos_pdf, content_type="pdf")
    nombre = "TodosLosPdfs_"+request.user.sede+" ("+str(now)+").pdf"
    response["Content-Disposition"] = f'attachment; filename={nombre}'
    return response
    #return FileResponse(todos_pdf, content_type='application/pdf', filename=("TodosLosPdfs_"+request.user.sede+" ("+str(now)+")"))


@login_required
@permission_required('plataforma.ADMIN', raise_exception=True)
def admin_borrar_todo(request):
    contraseña = request.POST['contraseña_borrar'].strip()
    comparar = request.user.username + "_trasnoa"
    if contraseña == comparar:
        estaciones = User.objects.filter(rol=2,sede=request.user.sede)
        plantillas = Plantilla.objects.filter(eett__in=estaciones)
        plantillas= plantillas.order_by("eett").all()
        for plantilla in plantillas:
            for contenido in plantilla.contenido.all():
                Contenido.objects.filter(id=contenido.id).delete()
            Plantilla.objects.filter(id=plantilla.id).delete()
        avisos = User.objects.filter(rol=1,sede=request.user.sede)
        for aviso in avisos:
            Mensaje.objects.filter(receptor = aviso).delete()
    return HttpResponseRedirect(reverse("inicio_admin"))