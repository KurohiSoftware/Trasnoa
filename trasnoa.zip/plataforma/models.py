from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    sede = models.CharField(max_length=128)
    USER_TYPE_CHOICES = (
      (1, 'admin'),
      (2, 'eett'),
      (3, 'creador'),
    )
    rol = models.PositiveSmallIntegerField(choices=USER_TYPE_CHOICES, default = 1)
    class Meta:
        permissions = (("ADMIN", "is_admin"),("EETT", "is_eett"),("CREADOR","is_creador"))


class Contenido(models.Model):
    codigo = models.CharField(max_length=128)
    clase = models.CharField(max_length=128)
    observacion = models.CharField(max_length=2000)
    identificador = models.CharField(max_length=128,blank=True,null=True)

class Plantilla(models.Model):
    eett = models.ForeignKey(User, on_delete=models.CASCADE, related_name = "estacion", default = None)
    fecha = models.DateTimeField()
    fecha_subida = models.DateTimeField()
    operador = models.CharField(max_length=128)
    DNI = models.CharField(max_length=128)
    temperatura = models.CharField(max_length=128)
    clima = models.CharField(max_length=128)
    tipo = models.CharField(max_length=128)
    contenido = models.ManyToManyField(Contenido, related_name = "contenido", default = None)

    def serialize(self):
        return {
            "id": self.id,
            "eett": self.eett.username,
            "fecha": self.fecha,
            "fecha_subida": self.fecha_subida
        }

class Mensaje(models.Model):
    receptor = models.ForeignKey(User, on_delete=models.CASCADE, related_name = "receptor", default = None)
    plantilla = models.ForeignKey(Plantilla, on_delete=models.CASCADE, related_name = "plantilla", default = None)
    avisos = models.ManyToManyField(Contenido, related_name = "avisos", default = None)
    leido = models.BooleanField(default=False, blank=True, null=True)
    def serialize(self):
        return {
            "id": self.id,
            "plantilla": self.plantilla,
            "leido": self.leido,
        }