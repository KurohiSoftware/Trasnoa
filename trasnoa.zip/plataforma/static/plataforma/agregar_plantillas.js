document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('#agregar_renglon').addEventListener('click', () => agregar_fila());
});

function agregar_fila() {
    var nFilas = $("#tabla_plantilla tbody tr").length;
    var cD = document.getElementById('contador_django');
    cD.setAttribute('value', nFilas)
    document.getElementById('tabla_plantilla').insertRow(-1).innerHTML = `<tr><td>${nFilas}</td><td><input style="width:100px" maxlength="128" id="identificador_${nFilas}" onchange="cambiar_tipo(${nFilas})"  class="form-control" type="text" name="codigo_${nFilas}" autocomplete="off"></td><td><select style="width:130px" class="form-select" name="tipo_chequeo_${nFilas}"><option>Obligatorio</option><option>Novedad</option></select></td><td id="fila_${nFilas}"><textarea style="width:calc(100px + 44vw);display: block;overflow: hidden;resize: none;" id="autoresizing" class="form-control" type="text" name="observacion_${nFilas}" maxlength="2000" rows="1"></textarea></td><td><input style="width:150px" maxlength="128" class="form-control" type="text" name="identificador_${nFilas}"></td></tr>`
}
