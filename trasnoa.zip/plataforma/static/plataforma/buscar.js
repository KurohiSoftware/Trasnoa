document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('#busqueda_primera').addEventListener('change', () => cambiar_opcion_1());
    document.querySelector('#busqueda_segunda').addEventListener('change', () => cambiar_opcion_2());
});



function cambiar_opcion_1() {
    const select1 = document.querySelector('#busqueda_primera');
    const select2 = document.querySelector('#busqueda_segunda');
    fetch(`/plantillas_json`)
    .then(response => response.json())
    .then(plantillas => {
        const contenido = document.querySelector('#contenido');
        var weekNumber = 0;
        var weekdefault = 0;
        if (select1.value == "Mes"){
            select2.innerHTML = ""
            var x = ""
            var options = { month: 'long'};
            for (let i = 0; i < plantillas.length ; i++) {
                var fecha  = new Date(plantillas[i].fecha);
                fecha.setTime( fecha.getTime() + fecha.getTimezoneOffset()*60*1000 );

                startDate = new Date(fecha.getFullYear(), 0, 1);
                var days = Math.floor((fecha - startDate) / (24 * 60 * 60 * 1000));
                if (weekNumber == 0){
                    weekNumber = Math.ceil(days / 7);
                    weekdefault = weekNumber;
                }
                else{
                    weekNumber = Math.ceil(days / 7);
                }
                y = `<option id="fecha" value=${weekNumber}>${fecha.toLocaleDateString("es",options) + " " + weekNumber}</option>`;
                if(!(x.includes(y))){
                    x = x + y;
                }
            }
            select2.insertAdjacentHTML('beforeend', x);
            x = `<h1>Planillas de la semana: ${weekdefault}</h1><table class="table table-dark table-hover table-striped mb-0"><tr>
            <th>EETT</th>
            <th>Fecha realizacion</th>
            <th>Fecha subida</th>
            <th>Ver plantilla</th>
            </tr>`;
            plantillas.forEach(plantillas => {
                fecha  = new Date(plantillas.fecha);
                fecha.setTime( fecha.getTime() + fecha.getTimezoneOffset()*60*1000 );
                fecha_subida = new Date(plantillas.fecha_subida);
                fecha_subida.setTime( fecha_subida.getTime() + fecha_subida.getTimezoneOffset()*60*1000 );
                startDate = new Date(fecha.getFullYear(), 0, 1);
                days = Math.floor((fecha - startDate) / (24 * 60 * 60 * 1000));
                weekNumber = Math.ceil(days / 7);

                if(weekNumber == weekdefault){
                    y = `<tr>
                    <td>${plantillas.eett}</td>
                    <td>${fecha.toLocaleDateString()} ${fecha.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td>${fecha_subida.toLocaleDateString()} ${fecha_subida.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td><a href="/PlantillaN%C2%B0:${plantillas.id}" %}">Abrir</a></td>
                    </tr>`;
                    x = x + y;
                }
            });
            x = x + `</table>`;
            contenido.innerHTML = x;
        }
        if (select1.value == "EETT"){
            var x = ""
            select2.innerHTML = ""
            for (let i = 0; i < plantillas.length ; i++) {
                y = `<option id="estacion">${plantillas[i].eett}</option>`;
                if(!(x.includes(y))){
                    x = x + y;
                }
            }
            select2.insertAdjacentHTML('beforeend', x);
            var x = `<h1>Planillas de la estacion transformadora: ${plantillas[0].eett}</h1><table class="table table-dark table-hover table-striped mb-0"><tr>
            <th>EETT</th>
            <th>Fecha realizacion</th>
            <th>Fecha subida</th>
            <th>Ver plantilla</th>
            </tr>`;
            plantillas_default = plantillas[0].eett
            plantillas.forEach(plantillas => {
                if(plantillas.eett == plantillas_default){
                    fecha  = new Date(plantillas.fecha);
                    fecha.setTime( fecha.getTime() + fecha.getTimezoneOffset()*60*1000 );
                    fecha_subida = new Date(plantillas.fecha_subida);
                    fecha_subida.setTime( fecha_subida.getTime() + fecha_subida.getTimezoneOffset()*60*1000 );
                    y = `<tr>
                    <td>${plantillas.eett}</td>
                    <td>${fecha.toLocaleDateString()} ${fecha.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td>${fecha_subida.toLocaleDateString()} ${fecha_subida.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td><a href="/PlantillaN%C2%B0:${plantillas.id}" %}">Abrir</a></td>
                    </tr>`;
                    x = x + y;
                }
            });
            x = x + `</table>`;
            contenido.innerHTML = x;
        }
        if (select1.value == "Inicio"){
            select2.innerHTML = ""
            var x = `<table class="table table-dark table-hover table-striped mb-0"><tr>
            <th>EETT</th>
            <th>Fecha realizacion</th>
            <th>Fecha subida</th>
            <th>Ver planilla</th>
            </tr>`;
            plantillas_default = plantillas[0].eett
            plantillas.forEach(plantillas => {
                fecha  = new Date(plantillas.fecha);
                fecha.setTime( fecha.getTime() + fecha.getTimezoneOffset()*60*1000 );
                fecha_subida = new Date(plantillas.fecha_subida);
                fecha_subida.setTime( fecha_subida.getTime() + fecha_subida.getTimezoneOffset()*60*1000 );
                y = `<tr>
                <td>${plantillas.eett}</td>
                <td>${fecha.toLocaleDateString()} ${fecha.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                <td>${fecha_subida.toLocaleDateString()} ${fecha_subida.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                <td><a href="/PlantillaN%C2%B0:${plantillas.id}" %}">Abrir</a></td>
                </tr>`;
                x = x + y;
            });
            x = x + `</table>`;
            contenido.innerHTML = x;
        }
    });
}

function cambiar_opcion_2() {
    const select2 = document.querySelector('#busqueda_segunda');
    var es_estacion = document.querySelector('#estacion');
    var es_fecha = document.querySelector('#fecha');
    const contenido = document.querySelector('#contenido');
    fetch(`/plantillas_json`)
    .then(response => response.json())
    .then(plantillas => {
        if (es_estacion != null){
            var x = `<h1>Planillas de la estacion transformadora: ${select2.value}</h1><table class="table table-dark table-hover table-striped mb-0"><tr>
            <th>EETT</th>
            <th>Fecha realizacion</th>
            <th>Fecha subida</th>
            <th>Ver planilla</th>
            </tr>`;
            plantillas.forEach(plantillas => {
                if(plantillas.eett == select2.value){
                    fecha  = new Date(plantillas.fecha);
                    fecha.setTime( fecha.getTime() + fecha.getTimezoneOffset()*60*1000 );
                    fecha_subida = new Date(plantillas.fecha_subida);
                    fecha_subida.setTime( fecha_subida.getTime() + fecha_subida.getTimezoneOffset()*60*1000 );
                    y = `<tr>
                    <td>${plantillas.eett}</td>
                    <td>${fecha.toLocaleDateString()} ${fecha.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td>${fecha_subida.toLocaleDateString()} ${fecha_subida.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td><a href="/PlantillaN%C2%B0:${plantillas.id}" %}">Abrir</a></td>
                    </tr>`;
                    x = x + y;
                }
            });
            x = x + `</table>`;
            contenido.innerHTML = x;
        }
        else if (es_fecha != null){
            var x = `<h1>Planillas de la semana: ${select2.value}</h1><table class="table table-dark table-hover table-striped mb-0"><tr>
            <th>EETT</th>
            <th>Fecha realizacion</th>
            <th>Fecha subida</th>
            <th>Ver planilla</th>
            </tr>`;
            plantillas.forEach(plantillas => {
                fecha  = new Date(plantillas.fecha);
                fecha.setTime( fecha.getTime() + fecha.getTimezoneOffset()*60*1000 );
                fecha_subida = new Date(plantillas.fecha_subida);
                fecha_subida.setTime( fecha_subida.getTime() + fecha_subida.getTimezoneOffset()*60*1000 );
                startDate = new Date(fecha.getFullYear(), 0, 1);
                var days = Math.floor((fecha - startDate) / (24 * 60 * 60 * 1000));
                var weekNumber = Math.ceil(days / 7);

                if(weekNumber == select2.value){
                    y = `<tr>
                    <td>${plantillas.eett}</td>
                    <td>${fecha.toLocaleDateString()} ${fecha.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td>${fecha_subida.toLocaleDateString()} ${fecha_subida.toLocaleTimeString(['es-ar'], {hour: '2-digit', minute:'2-digit'})}</td>
                    <td><a href="/PlantillaN%C2%B0:${plantillas.id}" %}">Abrir</a></td>
                    </tr>`;
                    x = x + y;
                }
            });
            x = x + `</table>`;
            contenido.innerHTML = x;
        }
    });
}
