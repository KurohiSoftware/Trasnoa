
function cambiar_tipo(numero) {
    let numeros = ["EP03S01", "EP03S02","EP03S03","CT08S07","CT08S09","CT11D01","CL20D01","CL20D02","CL20D03","CT14D02","CT15D02","CT16D02","CL25D02"]
    let aceites = ["EP06D0101","EP06D0103","EP07D0101","EP07D0103","CT08S04","CT08S05","CT10S02","CT11D0201","CT11D0202","CL20D0401","CL20D0402","CL22S01","CL23S01","CT13S01"]
    var codigo = document.getElementById(`identificador_${numero}`);
    var fila = document.getElementById(`fila_${numero}`);
    console.log(codigo.value.trim().toUpperCase())
    if (numeros.includes(codigo.value.trim().toUpperCase())){
        fila.innerHTML = `<input class="form-control" type="number" min="0" name="observacion_${numero}">`
    }
    else if (aceites.includes(codigo.value.trim())){
        fila.innerHTML = `<select class="form-select" name="observacion_${numero}">
        <option>Minimo</option>
        <option>Bajo</option>
        <option>Normal</option>
        <option>Alto</option>
        <option>Máximo</option>
        </select>`
    }
    else if (codigo.value.trim() == "EP03S09"){
        fila.innerHTML = `<select class="form-select" name="observacion_${numero}">
        <option>Menor que minimo</option>
        <option>Minimo</option>
        <option>Medio</option>
        <option>Máximo</option>
        <option>Mayor a máximo</option>
        </select>`
    }
    else{
        fila.innerHTML = `<textarea class="form-control" type="text" name="observacion_${numero}" maxlength="2000" rows="1"></textarea>`
    }
}
