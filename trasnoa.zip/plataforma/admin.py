from django.contrib import admin
from .models import User, Plantilla, Contenido, Mensaje

admin.site.register(User)
admin.site.register(Plantilla)
admin.site.register(Contenido)
admin.site.register(Mensaje)
