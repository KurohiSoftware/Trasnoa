from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("ingresar", views.ingresar, name="ingresar"),
    path("crear_cuentas", views.crear_cuentas, name="crear_cuentas"),
    path("registrar", views.registrar, name="registrar"),
    path("cerrar_sesion", views.cerrar_sesion, name="cerrar_sesion"),
    path("inicio_estacion", views.inicio_estacion, name="inicio_estacion"),
    path("ver_checklist", views.ver_checklist, name="ver_checklist"),
    path("inicio_admin", views.inicio_admin, name="inicio_admin"),
    path("Ver aviso:<int:aviso_id>", views.ver_aviso, name="ver_aviso"),
    path("leido:<int:aviso_id>", views.leido, name="leido"),
    path("no_leido:<int:aviso_id>", views.no_leido, name="no_leido"),
    path("ver_estaciones", views.ver_estaciones, name="ver_estaciones"),
    path("admin_plantillas", views.admin_plantillas, name="admin_plantillas"),
    path("PlantillaN°:<int:plantilla_id>", views.admin_ver_plantilla, name="admin_ver_plantilla"),
    path("admin_descargar_planilla:<int:plantilla_id>", views.admin_descargar_planilla, name="admin_descargar_planilla"),
    path("PlantillaModificar:<int:plantilla_id>", views.admin_modificar_plantilla, name="admin_modificar_plantilla"),
    path("admin_agregar_plantilla", views.admin_agregar_plantilla, name="admin_agregar_plantilla"),
    path("<int:plantilla_eliminar>", views.admin_eliminar, name="admin_eliminar"),
    path("plantillas_json", views.plantillas_json, name="plantillas_json"),
    path("admin_estadistica", views.admin_estadistica, name="admin_estadistica"),
    path("admin_todos_pdf", views.admin_todos_pdf, name="admin_todos_pdf"),
    path("admin_borrar_todo", views.admin_borrar_todo, name="admin_borrar_todo"),
    path("error:<int:plantilla_eliminar>", views.error, name="error"),
    path("cambiar_contrasena:<int:usuario_id>", views.cambiar_contrasena, name="cambiar_contrasena")
]